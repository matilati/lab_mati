public class Pregunta {
String enunciado;
int puntaje_pregunta;

    public int getPuntaje_pregunta() {
        return puntaje_pregunta;
    }

    public void setPuntaje_pregunta(int puntaje_pregunta) {
        this.puntaje_pregunta = puntaje_pregunta;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }
}
