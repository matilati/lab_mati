import java.util.Scanner;

public class Main {
    public static void  main (String [] args)
    {
        Prueba prueba = new Prueba();
        prueba.seleccionar_preguntas();
    }



}
